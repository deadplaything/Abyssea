require('common');

local imgui = require('imgui');
local ffi = require('ffi');
local bit = require('bit');
local settings = require('settings');
local data = require('data.abyssea_data');

addon.name      = 'abyssea';
addon.author    = 'IntegReady';
addon.version   = '0.9.7';
addon.desc      = 'Abyssea NM progression, key item, pop item, abyssite and atma tracker with acquisition alerts.';
addon.link      = '';


local persisted = settings.load(T{
    version = 1,
    characters = {},
});

local function get_character_key()
    local ok, name = pcall(function()
        local party = AshitaCore:GetMemoryManager():GetParty();
        if party ~= nil then return party:GetMemberName(0); end
        return nil;
    end);
    if ok and name ~= nil and #tostring(name) > 0 then
        return tostring(name):lower();
    end
    return 'default';
end

local function get_persisted_keyitems()
    local key = get_character_key();
    persisted.characters[key] = persisted.characters[key] or { keyitems = {} };
    persisted.characters[key].keyitems = persisted.characters[key].keyitems or {};
    return persisted.characters[key].keyitems;
end

local function save_persisted_keyitems()
    pcall(function() settings.save(); end);
end

local state = {
    open = { true },
    selected_zone = 1,
    selected_nm = {},
    keyitem_ids = {},
    keyitem_names = {},
    item_ids = {},
    item_owned = {},
    lookup_ready = false,
    last_item_scan = 0,
    last_monitor_scan = 0,
    monitor_ready = false,
    keyitem_snapshot = {},
    item_snapshot = {},
    item_event_generation = 0,
    keyitem_event_generation = 0,
    packet_keyitems = {},
    packet_keyitem_pages = {},
    zoning = false,
    sounds_enabled = { true },
    sound_item = { true },
    sound_keyitem = { true },
    sound_abyssite = { true },
    sound_atma = { true },
    compact_mode = { false },
    tracker_open = { true },
    tracked_nms = {},
    abyssite_search = { '' },
    atma_search = { '' },
};

local colors = {
    title   = { 0.95, 0.78, 0.35, 1.00 },
    header  = { 0.78, 0.84, 0.95, 1.00 },
    owned   = { 0.25, 0.95, 0.35, 1.00 },
    missing = { 1.00, 0.25, 0.25, 1.00 },
    source  = { 0.68, 0.72, 0.78, 1.00 },
    muted   = { 0.52, 0.56, 0.62, 1.00 },
    normal  = { 0.90, 0.90, 0.92, 1.00 },
};

local theme = {
    windowBg       = { 0.045, 0.060, 0.095, 0.985 },
    titleBg        = { 0.060, 0.095, 0.150, 0.995 },
    titleBgActive  = { 0.085, 0.145, 0.225, 0.995 },
    border         = { 0.22, 0.42, 0.62, 0.82 },
    childBg        = { 0.065, 0.085, 0.125, 0.970 },
    frameBg        = { 0.075, 0.105, 0.155, 0.95 },
    frameHover     = { 0.11, 0.17, 0.25, 0.98 },
    tab            = { 0.065, 0.105, 0.165, 0.98 },
    tabHovered     = { 0.16, 0.31, 0.47, 0.98 },
    tabActive      = { 0.18, 0.39, 0.58, 1.00 },
    header         = { 0.12, 0.27, 0.40, 0.84 },
    headerHovered  = { 0.18, 0.38, 0.55, 0.90 },
    headerActive   = { 0.22, 0.47, 0.67, 0.95 },
    scrollbarBg    = { 0.035, 0.050, 0.075, 0.80 },
    scrollbarGrab  = { 0.18, 0.38, 0.56, 0.85 },
    checkmark      = { 0.38, 0.78, 1.00, 1.00 },
    accent         = { 0.42, 0.78, 1.00, 1.00 },
};

ffi.cdef[[
    int __stdcall PlaySoundA(const char* pszSound, void* hmod, unsigned int fdwSound);
]];
local winmm = ffi.load('winmm');
local SND_ASYNC    = 0x0001;
local SND_NODEFAULT= 0x0002;
local SND_FILENAME = 0x00020000;

local SOUND_FILES = {
    item     = 'sounds\\item.wav',
    keyitem  = 'sounds\\keyitem.wav',
    abyssite = 'sounds\\abyssite.wav',
    atma     = 'sounds\\atma.wav',
};

local function play_chime(kind)
    if not state.sounds_enabled[1] then return; end
    if kind == 'item' and not state.sound_item[1] then return; end
    if kind == 'keyitem' and not state.sound_keyitem[1] then return; end
    if kind == 'abyssite' and not state.sound_abyssite[1] then return; end
    if kind == 'atma' and not state.sound_atma[1] then return; end
    local rel = SOUND_FILES[kind];
    if rel == nil then return; end
    local path = addon.path .. rel;
    pcall(function()
        winmm.PlaySoundA(path, nil, SND_ASYNC + SND_NODEFAULT + SND_FILENAME);
    end);
end

local function push_theme()
    imgui.PushStyleColor(ImGuiCol_WindowBg, theme.windowBg);
    imgui.PushStyleColor(ImGuiCol_TitleBg, theme.titleBg);
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, theme.titleBgActive);
    imgui.PushStyleColor(ImGuiCol_Border, theme.border);
    imgui.PushStyleColor(ImGuiCol_ChildBg, theme.childBg);
    imgui.PushStyleColor(ImGuiCol_FrameBg, theme.frameBg);
    imgui.PushStyleColor(ImGuiCol_FrameBgHovered, theme.frameHover);
    imgui.PushStyleColor(ImGuiCol_Tab, theme.tab);
    imgui.PushStyleColor(ImGuiCol_TabHovered, theme.tabHovered);
    imgui.PushStyleColor(ImGuiCol_TabActive, theme.tabActive);
    imgui.PushStyleColor(ImGuiCol_Header, theme.header);
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, theme.headerHovered);
    imgui.PushStyleColor(ImGuiCol_HeaderActive, theme.headerActive);
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg, theme.scrollbarBg);
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab, theme.scrollbarGrab);
    imgui.PushStyleColor(ImGuiCol_CheckMark, theme.checkmark);
    imgui.PushStyleVar(ImGuiStyleVar_WindowRounding, 7);
    imgui.PushStyleVar(ImGuiStyleVar_ChildRounding, 5);
    imgui.PushStyleVar(ImGuiStyleVar_FrameRounding, 4);
    imgui.PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 5);
    imgui.PushStyleVar(ImGuiStyleVar_TabRounding, 4);
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 10, 9 });
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { 5, 4 });
end

local function pop_theme()
    imgui.PopStyleVar(7);
    imgui.PopStyleColor(16);
end

local CONTAINERS = {
    { id = 0,  name = 'Inventory' },  { id = 1,  name = 'Safe' },
    { id = 2,  name = 'Storage' },    { id = 4,  name = 'Locker' },
    { id = 5,  name = 'Satchel' },    { id = 6,  name = 'Sack' },
    { id = 7,  name = 'Case' },       { id = 8,  name = 'Wardrobe' },
    { id = 9,  name = 'Safe 2' },     { id = 10, name = 'Wardrobe 2' },
    { id = 11, name = 'Wardrobe 3' }, { id = 12, name = 'Wardrobe 4' },
    { id = 13, name = 'Wardrobe 5' }, { id = 14, name = 'Wardrobe 6' },
    { id = 15, name = 'Wardrobe 7' }, { id = 16, name = 'Wardrobe 8' },
};

local function normalize(s)
    return (s or ''):lower():gsub('[^%w]', '');
end

-- FFXI frequently abbreviates item display names (for example,
-- 'Tr. Insect Wing' vs. the full log name 'Transparent insect wing').
-- Compare both exact normalized names and token-by-token abbreviations so
-- the tracker can safely resolve normal client abbreviations such as Tr. / H.Q.
local function tokenize_name(s)
    local out = {};
    for token in (s or ''):lower():gmatch('[%w]+') do
        table.insert(out, token);
    end
    return out;
end

local function item_name_matches(wanted, candidate)
    if wanted == nil or candidate == nil or wanted == '' or candidate == '' then return false; end
    if normalize(wanted) == normalize(candidate) then return true; end

    local a = tokenize_name(wanted);
    local b = tokenize_name(candidate);
    if #a ~= #b or #a == 0 then return false; end

    for i = 1, #a do
        local x, y = a[i], b[i];
        if x ~= y then
            local shorter, longer = x, y;
            if #shorter > #longer then shorter, longer = longer, shorter; end
            -- A shorter token must be a true prefix of the longer token.
            -- This handles 'tr' -> 'transparent' and 'q' -> 'quality'.
            if longer:sub(1, #shorter) ~= shorter then return false; end
        end
    end
    return true;
end

local function resource_item_names(res)
    local names = {};
    if res == nil then return names; end
    local function add(v)
        if v ~= nil and type(v) == 'string' and #v > 0 then table.insert(names, v); end
    end
    if res.Name ~= nil then
        if type(res.Name) == 'string' then add(res.Name);
        else
            add(res.Name[0]); add(res.Name[1]); add(res.Name[2]);
        end
    end
    if res.LogNameSingular ~= nil then
        if type(res.LogNameSingular) == 'string' then add(res.LogNameSingular);
        else
            add(res.LogNameSingular[0]); add(res.LogNameSingular[1]); add(res.LogNameSingular[2]);
        end
    end
    return names;
end

local function build_keyitem_lookup()
    state.keyitem_ids = {};
    state.keyitem_names = {};
    local rm = AshitaCore:GetResourceManager();
    for id = 0, 65535 do
        local name = rm:GetString('keyitems.names', id);
        if name ~= nil and #name > 1 then
            local key = normalize(name);
            state.keyitem_ids[key] = state.keyitem_ids[key] or {};
            table.insert(state.keyitem_ids[key], id);
            table.insert(state.keyitem_names, { id = id, name = name });
        end
    end
end

-- Resolve a database KI name against Ashita's key-item strings. FFXI resource
-- names can be abbreviated just like normal item names, so first try the fast
-- exact normalized lookup and then fall back to the same prefix/token matcher
-- used for physical items (for example an abbreviated first word or H.Q.).
local function resolve_keyitem_ids(name)
    local key = normalize(name);
    local ids = state.keyitem_ids[key];
    if ids ~= nil and #ids > 0 then return ids; end

    local matched = {};
    for _, entry in ipairs(state.keyitem_names or {}) do
        if item_name_matches(name, entry.name) then
            table.insert(matched, entry.id);
        end
    end

    if #matched > 0 then
        -- Cache the database spelling too so future checks are cheap.
        state.keyitem_ids[key] = matched;
        return matched;
    end
    return nil;
end

local function gather_pop_item_names()
    local names = {};
    for _, zone in ipairs(data.zones) do
        for _, nm in ipairs(zone.nms) do
            for _, req in ipairs(nm.requirements or {}) do
                if req.type == 'item' and req.name then names[normalize(req.name)] = req.name; end
            end
        end
    end
    return names;
end

local function build_item_lookup()
    state.item_ids = {};
    local needed = gather_pop_item_names();
    local remaining = 0;
    for _ in pairs(needed) do remaining = remaining + 1; end
    if remaining == 0 then return; end

    local rm = AshitaCore:GetResourceManager();
    for id = 1, 65535 do
        local res = rm:GetItemById(id);
        if res ~= nil then
            local resource_names = resource_item_names(res);
            for needed_key, wanted_name in pairs(needed) do
                if state.item_ids[needed_key] == nil then
                    local matched = false;
                    for _, resource_name in ipairs(resource_names) do
                        -- Physical items must resolve exactly against one of Ashita's
                        -- resource names. GetItemById exposes both the abbreviated display
                        -- name and the full log name, so normal FFXI abbreviations do not
                        -- require fuzzy matching here. Exact matching prevents unrelated
                        -- inventory items from producing false OWNED states.
                        if normalize(wanted_name) == normalize(resource_name) then
                            state.item_ids[needed_key] = id;
                            remaining = remaining - 1;
                            matched = true;
                            break;
                        end
                    end
                    if matched and remaining <= 0 then break; end
                end
            end
            if remaining <= 0 then break; end
        end
    end
end

local function rebuild_lookups()
    build_keyitem_lookup();
    build_item_lookup();
    state.lookup_ready = true;
end

-- 0x055 contains the server's authoritative Key Item Log as 512-bit pages.
-- When we have seen the page for a KI, prefer that packet-backed state. This
-- avoids depending on the client memory wrapper being refreshed immediately
-- on every server implementation. If a page has not been seen since load,
-- fall back to Ashita's Player:HasKeyItem() just like ItemWatch does.
local function packet_has_keyitem(id)
    local page = math.floor(id / 0x200);
    if state.packet_keyitem_pages[page] then
        return state.packet_keyitems[id] == true, true;
    end
    return false, false;
end

local function persisted_has_keyitem(id)
    local owned = get_persisted_keyitems()[tostring(id)];
    return owned == true;
end

local function remember_keyitem(id, owned)
    local cache = get_persisted_keyitems();
    local k = tostring(id);
    if owned then cache[k] = true; else cache[k] = nil; end
end

local function has_keyitem(name)
    if not state.lookup_ready then rebuild_lookups(); end
    local ids = resolve_keyitem_ids(name);
    if ids == nil or #ids == 0 then return false, nil; end
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    for _, id in ipairs(ids) do
        local owned, authoritative = packet_has_keyitem(id);
        if authoritative then
            if owned then return true, id; end
        elseif player ~= nil and player:HasKeyItem(id) then
            remember_keyitem(id, true);
            return true, id;
        elseif persisted_has_keyitem(id) then
            return true, id;
        end
    end
    return false, ids[1];
end

local function keyitem_count(name)
    if not state.lookup_ready then rebuild_lookups(); end
    local ids = resolve_keyitem_ids(name);
    if ids == nil then return 0, 0; end
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    local count = 0;
    for _, id in ipairs(ids) do
        local owned, authoritative = packet_has_keyitem(id);
        local memory_owned = (not authoritative and player ~= nil and player:HasKeyItem(id));
        if memory_owned then remember_keyitem(id, true); end
        if (authoritative and owned) or memory_owned or (not authoritative and persisted_has_keyitem(id)) then
            count = count + 1;
        end
    end
    return count, #ids;
end

local function scan_items(force)
    local now = os.time();
    if not force and (now - state.last_item_scan) < 2.0 then return; end
    state.last_item_scan = now;
    state.item_owned = {};
    if not state.lookup_ready then rebuild_lookups(); end

    local watch = {};
    for _, id in pairs(state.item_ids) do watch[id] = true; end
    local inventory = AshitaCore:GetMemoryManager():GetInventory();
    if inventory == nil then return; end

    local rm = AshitaCore:GetResourceManager();
    local needed = gather_pop_item_names();

    for _, container in ipairs(CONTAINERS) do
        local max = inventory:GetContainerCountMax(container.id);
        if max ~= nil and max > 0 then
            -- Do not stop on an empty / unavailable slot. Containers can have gaps,
            -- especially after items are injected, moved, sorted, or received.
            for slot = 0, max do
                local ok, invitem = pcall(function() return inventory:GetContainerItem(container.id, slot); end);
                if ok and invitem ~= nil and invitem.Id ~= 0 and invitem.Id ~= 65535 then
                    local tracked = watch[invitem.Id] == true;

                    -- Fallback: resolve the item by the name Ashita reports for the actual
                    -- owned inventory entry. This protects us from resource lookup aliases
                    -- / capitalization differences in the static lookup pass.
                    if not tracked then
                        local res = rm:GetItemById(invitem.Id);
                        if res ~= nil then
                            local resource_names = resource_item_names(res);
                            for needed_key, wanted_name in pairs(needed) do
                                if state.item_ids[needed_key] == nil or state.item_ids[needed_key] == invitem.Id then
                                    for _, resource_name in ipairs(resource_names) do
                                        -- Same rule as the static lookup: exact match only.
                                        -- Ashita provides short and full item names, so this
                                        -- remains abbreviation-safe without fuzzy collisions.
                                        if normalize(wanted_name) == normalize(resource_name) then
                                            state.item_ids[needed_key] = invitem.Id;
                                            watch[invitem.Id] = true;
                                            tracked = true;
                                            break;
                                        end
                                    end
                                end
                                if tracked then break; end
                            end
                        end
                    end

                    if tracked then
                        local count = invitem.Count or 1;
                        local old = state.item_owned[invitem.Id];
                        if old == nil then
                            state.item_owned[invitem.Id] = { count = count, locations = { container.name } };
                        else
                            old.count = old.count + count;
                            local exists = false;
                            for _, n in ipairs(old.locations) do if n == container.name then exists = true; break; end end
                            if not exists then table.insert(old.locations, container.name); end
                        end
                    end
                end
            end
        end
    end
end

local function item_status(name)
    if not state.lookup_ready then rebuild_lookups(); end
    local id = state.item_ids[normalize(name)];
    if id == nil then return false, nil, nil; end
    local info = state.item_owned[id];
    return info ~= nil, id, info;
end

local function req_owned(req)
    if req.type == 'ki' then return has_keyitem(req.name); end
    if req.type == 'item' then return item_status(req.name); end
    return true, nil;
end

local function nm_ready(nm)
    if not nm.requirements or #nm.requirements == 0 then return true; end
    for _, req in ipairs(nm.requirements) do
        local owned = req_owned(req);
        if not owned then return false; end
    end
    return true;
end

local function sorted_nms(zone)
    local out = {};
    for i, nm in ipairs(zone.nms or {}) do out[#out + 1] = { nm = nm, index = i }; end
    table.sort(out, function(a, b) return a.nm.name:lower() < b.nm.name:lower(); end);
    return out;
end


local function build_collection_sets()
    local abyssites, atmas = {}, {};
    for _, entry in ipairs(data.abyssites or {}) do abyssites[normalize(entry.name)] = true; end
    for _, entry in ipairs(data.atmas or {}) do atmas[normalize(entry.name)] = true; end
    return abyssites, atmas;
end

local function gather_watched_keyitems()
    local watched = {};
    local abyssites, atmas = build_collection_sets();
    for _, zone in ipairs(data.zones or {}) do
        for _, nm in ipairs(zone.nms or {}) do
            for _, req in ipairs(nm.requirements or {}) do
                if req.type == 'ki' and req.name then watched[normalize(req.name)] = { name = req.name, kind = 'keyitem' }; end
            end
            for _, reward in ipairs(nm.rewards or {}) do
                if reward.type == 'ki' and reward.name then watched[normalize(reward.name)] = { name = reward.name, kind = 'keyitem' }; end
            end
        end
    end
    for _, entry in ipairs(data.abyssites or {}) do watched[normalize(entry.name)] = { name = entry.name, kind = 'abyssite' }; end
    for _, entry in ipairs(data.atmas or {}) do watched[normalize(entry.name)] = { name = entry.name, kind = 'atma' }; end
    return watched;
end

local function current_item_count_by_name(name)
    local _, _, info = item_status(name);
    return info and (info.count or 0) or 0;
end


local function refresh_current_ownership()
    if not state.lookup_ready then rebuild_lookups(); end
    scan_items(true);

    -- One-time local-memory pass for all tracked KIs. Positive results are
    -- persisted; packet-backed pages remain authoritative for removals.
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    if player ~= nil then
        for _, entry in pairs(gather_watched_keyitems()) do
            local ids = resolve_keyitem_ids(entry.name) or {};
            for _, id in ipairs(ids) do
                local packet_owned, packet_known = packet_has_keyitem(id);
                if packet_known then
                    remember_keyitem(id, packet_owned);
                elseif player:HasKeyItem(id) then
                    remember_keyitem(id, true);
                end
            end
        end
    end
    save_persisted_keyitems();
end

local function initialize_monitor()
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    local inventory = AshitaCore:GetMemoryManager():GetInventory();
    if player == nil or inventory == nil then
        state.monitor_ready = false;
        return;
    end
    state.keyitem_snapshot = {};
    state.item_snapshot = {};
    for key, entry in pairs(gather_watched_keyitems()) do
        local count = keyitem_count(entry.name);
        state.keyitem_snapshot[key] = count;
    end
    for key, name in pairs(gather_pop_item_names()) do
        state.item_snapshot[key] = current_item_count_by_name(name);
    end
    state.monitor_ready = true;
end

local function detect_keyitem_changes()
    if state.zoning or not state.monitor_ready then return; end

    for key, entry in pairs(gather_watched_keyitems()) do
        local count = keyitem_count(entry.name);
        local old = state.keyitem_snapshot[key] or 0;
        if count > old then
            play_chime(entry.kind);
            print(('[Abyssea] Obtained %s: %s'):format(entry.kind == 'keyitem' and 'key item' or entry.kind, entry.name));
        end
        state.keyitem_snapshot[key] = count;
    end
end

local function detect_item_changes()
    if state.zoning or not state.monitor_ready then return; end

    -- This is a local-memory scan only. It does not send packets or requests
    -- to the game server. It is now only performed after FFXI reports that
    -- inventory data changed.
    scan_items(true);
    for key, name in pairs(gather_pop_item_names()) do
        local count = current_item_count_by_name(name);
        local old = state.item_snapshot[key] or 0;
        if count > old then
            play_chime('item');
            print(('[Abyssea] Obtained item: %s'):format(name));
        end
        state.item_snapshot[key] = count;
    end
end

local function queue_item_event_refresh()
    state.item_event_generation = state.item_event_generation + 1;
    local generation = state.item_event_generation;
    -- Let Ashita apply the incoming inventory packet to memory first, then
    -- refresh once. Consecutive packets collapse into the latest refresh.
    ashita.tasks.once(0.08, function()
        if generation ~= state.item_event_generation then return; end
        detect_item_changes();
    end);
end

local function parse_keyitem_log_packet(packet)
    if packet == nil or #packet < 0x88 then return false, nil; end

    -- Incoming 0x055 layout:
    --   0x04..0x43 = 0x40-byte availability bitfield
    --   0x44..0x83 = examined/new-state bitfield
    --   0x84..0x87 = page/type (each page represents 0x200 KI ids)
    local p1, p2, p3, p4 = packet:byte(0x84 + 1, 0x87 + 1);
    if p1 == nil then return false, nil; end
    local page = p1 + (p2 or 0) * 0x100 + (p3 or 0) * 0x10000 + (p4 or 0) * 0x1000000;
    if page < 0 or page > 127 then return false, page; end

    -- A 0x055 packet is a complete snapshot for this 512-KI page. Clear the
    -- previous page before applying the new bitfield.
    local first_id = page * 0x200;
    for id = first_id, first_id + 0x1FF do
        state.packet_keyitems[id] = nil;
    end

    for byte_index = 0, 0x3F do
        local value = packet:byte(0x04 + byte_index + 1) or 0;
        if value ~= 0 then
            for bit_index = 0, 7 do
                if bit.band(value, bit.lshift(1, bit_index)) ~= 0 then
                    local id = first_id + (byte_index * 8) + bit_index;
                    state.packet_keyitems[id] = true;
                end
            end
        end
    end
    state.packet_keyitem_pages[page] = true;

    -- Persist the authoritative state for this page so addon reloads preserve
    -- previously observed KI ownership without requesting anything from the server.
    for id = first_id, first_id + 0x1FF do
        remember_keyitem(id, state.packet_keyitems[id] == true);
    end
    save_persisted_keyitems();
    return true, page;
end

local function queue_keyitem_event_refresh()
    state.keyitem_event_generation = state.keyitem_event_generation + 1;
    local generation = state.keyitem_event_generation;
    -- Key Item Log packets can arrive as a short burst. Debounce them so the
    -- UI updates immediately after the burst without continuously polling.
    ashita.tasks.once(0.12, function()
        if generation ~= state.keyitem_event_generation then return; end
        detect_keyitem_changes();
    end);
end

local function render_sound_settings()
    imgui.TextColored(colors.header, 'ACQUISITION CHIMES');
    imgui.TextColored(colors.muted, 'Chimes are event-driven and play when FFXI reports an inventory or key-item change.');
    imgui.Separator();
    imgui.Checkbox('Enable sounds##aby_sound_master', state.sounds_enabled);
    imgui.Spacing();
    imgui.Checkbox('Physical pop items##aby_sound_item', state.sound_item);
    imgui.SameLine(280);
    if imgui.Button('Test##sound_item') then play_chime('item'); end
    imgui.Checkbox('Key items##aby_sound_keyitem', state.sound_keyitem);
    imgui.SameLine(280);
    if imgui.Button('Test##sound_keyitem') then play_chime('keyitem'); end
    imgui.Checkbox('Abyssites##aby_sound_abyssite', state.sound_abyssite);
    imgui.SameLine(280);
    if imgui.Button('Test##sound_abyssite') then play_chime('abyssite'); end
    imgui.Checkbox('Atmas##aby_sound_atma', state.sound_atma);
    imgui.SameLine(280);
    if imgui.Button('Test##sound_atma') then play_chime('atma'); end
    imgui.Spacing();
    imgui.Separator();
    imgui.TextColored(colors.header, 'DISPLAY MODE');
    imgui.TextColored(colors.muted, 'Full mode is for planning. Compact mode is a small farming panel.');
    if imgui.RadioButton('Full##aby_mode_full', not state.compact_mode[1]) then state.compact_mode[1] = false; end
    imgui.SameLine();
    if imgui.RadioButton('Compact##aby_mode_compact', state.compact_mode[1]) then state.compact_mode[1] = true; end
    imgui.Spacing();
    imgui.Spacing();
    imgui.Separator();
    imgui.TextColored(colors.header, 'PINNED NM TRACKER');
    imgui.Checkbox('Show pinned tracker##aby_tracker_open', state.tracker_open);
    imgui.TextColored(colors.muted, 'Pin an NM from its detail page, or use /aby track <NM name>.');
    imgui.TextColored(colors.muted, 'Commands: /aby mode full | compact  |  /aby tracker on/off/clear  |  /aby sound on/off');
end

local function tracker_key(zone_index, nm_name)
    return tostring(zone_index) .. '|' .. normalize(nm_name);
end

local function is_nm_tracked(zone_index, nm_name)
    return state.tracked_nms[tracker_key(zone_index, nm_name)] ~= nil;
end

local function add_tracked_nm(zone_index, nm)
    if nm == nil then return; end
    local key = tracker_key(zone_index, nm.name);
    state.tracked_nms[key] = { zone_index = zone_index, name = nm.name };
    state.tracker_open[1] = true;
end

local function remove_tracked_nm(zone_index, nm_name)
    state.tracked_nms[tracker_key(zone_index, nm_name)] = nil;
end

local function find_nm_in_zone(zone_index, name)
    local zone = data.zones[zone_index];
    if zone == nil then return nil; end
    local wanted = normalize(name);
    for _, nm in ipairs(zone.nms or {}) do
        if normalize(nm.name) == wanted then return nm; end
    end
    return nil;
end

local function tracked_count()
    local n = 0;
    for _ in pairs(state.tracked_nms) do n = n + 1; end
    return n;
end

local function render_tracker_requirement(zone_index, req, depth, visited)
    depth = depth or 0;
    visited = visited or {};
    local owned = req_owned(req);
    local c = owned and colors.owned or colors.missing;
    local indent = string.rep('   ', depth);
    local glyph = owned and '[+]' or '[-]';
    imgui.TextColored(c, indent .. glyph .. ' ' .. (req.name or 'Unknown'));

    if req.source and req.source ~= '' then
        local source_nm = find_nm_in_zone(zone_index, req.source);
        local tracker_source = requirement_source_text(zone_index, req);
        imgui.TextColored(colors.source, indent .. '    from ' .. tracker_source);
        if source_nm ~= nil and depth < 4 then
            local visit_key = normalize(source_nm.name);
            if not visited[visit_key] then
                visited[visit_key] = true;
                if source_nm.requirements and #source_nm.requirements > 0 then
                    for _, subreq in ipairs(source_nm.requirements) do
                        render_tracker_requirement(zone_index, subreq, depth + 1, visited);
                    end
                elseif source_nm.spawn_type then
                    imgui.TextColored(colors.muted, indent .. '      ' .. source_nm.spawn_type);
                end
                visited[visit_key] = nil;
            end
        end
    end
end

local function render_tracker_window()
    if tracked_count() == 0 or not state.tracker_open[1] then return; end

    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.025, 0.035, 0.055, 0.90 });
    imgui.PushStyleColor(ImGuiCol_Border, { 0.22, 0.42, 0.62, 0.72 });
    imgui.PushStyleVar(ImGuiStyleVar_WindowRounding, 6);
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 9, 8 });
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { 4, 2 });
    imgui.SetNextWindowSize({ 390, 420 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 285, 150 }, { 650, 900 });

    if imgui.Begin('NM Tracker##abyssea_tracker_overlay', state.tracker_open) then
        imgui.TextColored(colors.title, 'ABYSSEA TARGETS');
        imgui.SameLine();
        imgui.TextColored(colors.muted, ('%d pinned'):format(tracked_count()));
        imgui.SameLine(300);
        if imgui.SmallButton('CLEAR##tracker_clear') then state.tracked_nms = {}; end
        imgui.Separator();

        local ordered = {};
        for _, entry in pairs(state.tracked_nms) do table.insert(ordered, entry); end
        table.sort(ordered, function(a, b)
            if a.zone_index == b.zone_index then return a.name:lower() < b.name:lower(); end
            return a.zone_index < b.zone_index;
        end);

        for i, entry in ipairs(ordered) do
            local nm = find_nm_in_zone(entry.zone_index, entry.name);
            local zone = data.zones[entry.zone_index];
            if nm ~= nil and zone ~= nil then
                imgui.TextColored(nm_ready(nm) and colors.owned or colors.title, nm.name);
                imgui.SameLine();
                imgui.TextColored(colors.muted, '- ' .. (zone.short_name or zone.name));
                imgui.SameLine(330);
                if imgui.SmallButton('X##tracker_remove_' .. i) then
                    remove_tracked_nm(entry.zone_index, entry.name);
                end

                if nm.requirements and #nm.requirements > 0 then
                    local visited = { [normalize(nm.name)] = true };
                    for _, req in ipairs(nm.requirements) do
                        render_tracker_requirement(entry.zone_index, req, 0, visited);
                    end
                else
                    imgui.TextColored(colors.muted, nm.spawn_type or 'No tracked requirement.');
                end
                if i < #ordered then imgui.Separator(); end
            end
        end
    end
    imgui.End();
    imgui.PopStyleVar(3);
    imgui.PopStyleColor(2);
end

local function list_contains_normalized(list, name)
    if list == nil or name == nil then return false; end
    local wanted = normalize(name);
    for _, v in ipairs(list) do
        if normalize(v) == wanted then return true; end
    end
    return false;
end

local function requirement_has_gold_pyxis(zone_index, req)
    local zone = data.zones[zone_index];
    if zone == nil or req == nil then return false; end
    if req.type == 'ki' then
        return list_contains_normalized(zone.gold_pyxis_keyitems, req.name);
    end
    return list_contains_normalized(zone.gold_pyxis_items, req.name);
end

local function requirement_source_text(zone_index, req)
    local src = req.source or '';
    if requirement_has_gold_pyxis(zone_index, req) then
        if src ~= '' then return src .. ' / Gold Pyxis'; end
        return 'Gold Pyxis';
    end
    return src;
end

local function render_requirement(req, zone_index)
    local owned, id, info = req_owned(req);
    local status_color = owned and colors.owned or colors.missing;
    local label = (req.type == 'ki') and 'KEY ITEM' or 'POP ITEM';

    imgui.TextColored(status_color, owned and 'OWNED' or 'MISSING');
    imgui.SameLine(88);
    imgui.TextColored(colors.muted, label);
    imgui.SameLine(175);
    imgui.TextColored(status_color, req.name or 'Unknown');

    local source_text = requirement_source_text(zone_index, req);
    if source_text ~= '' then
        imgui.SameLine(530);
        imgui.TextColored(colors.source, 'From:');
        imgui.SameLine();
        imgui.TextColored(colors.source, source_text);
    end

    if req.type == 'item' and owned and info ~= nil then
        local where = table.concat(info.locations or {}, ', ');
        imgui.TextColored(colors.muted, ('    x%d  Stored: %s'):format(info.count or 1, where));
    elseif id == nil and imgui.IsItemHovered() then
        imgui.SetTooltip(req.type == 'ki' and 'Key item name was not found in Ashita resources.' or 'Item name was not found in Ashita resources.');
    end
end

local function render_nm_detail(nm, zone_index)
    imgui.TextColored(nm_ready(nm) and colors.owned or colors.title, nm.name);
    imgui.SameLine(700);
    if is_nm_tracked(zone_index, nm.name) then
        if imgui.SmallButton('UNTRACK##nm_track_btn') then remove_tracked_nm(zone_index, nm.name); end
    else
        if imgui.SmallButton('TRACK##nm_track_btn') then add_tracked_nm(zone_index, nm); end
    end
    if nm.location then
        imgui.SameLine();
        imgui.TextColored(colors.muted, nm.location);
    end
    imgui.Separator();

    if nm.spawn_type then
        imgui.TextColored(colors.header, 'Spawn:');
        imgui.SameLine();
        imgui.Text(nm.spawn_type);
    end
    if nm.respawn then
        imgui.SameLine(300);
        imgui.TextColored(colors.header, 'Respawn:');
        imgui.SameLine();
        imgui.Text(nm.respawn);
    end
    if nm.source_note then
        imgui.TextColored(colors.muted, nm.source_note);
    end

    imgui.Spacing();
    imgui.TextColored(colors.header, 'Requirements');
    imgui.Separator();
    if not nm.requirements or #nm.requirements == 0 then
        imgui.TextColored(colors.muted, 'No pop item or key item required.');
    else
        for _, req in ipairs(nm.requirements) do render_requirement(req, zone_index); end
    end

    if nm.rewards and #nm.rewards > 0 then
        imgui.Spacing();
        imgui.TextColored(colors.header, 'Progression Rewards');
        imgui.Separator();
        for _, reward in ipairs(nm.rewards) do
            local owned = false;
            if reward.type == 'ki' then owned = has_keyitem(reward.name); end
            imgui.TextColored(reward.type == 'ki' and (owned and colors.owned or colors.missing) or colors.normal, reward.name);
            if reward.used_for then
                imgui.SameLine(530);
                imgui.TextColored(colors.source, 'Used for: ' .. reward.used_for);
            end
        end
    end
end

local function render_zone(zone, zone_index)
    local list = sorted_nms(zone);
    if state.selected_nm[zone_index] == nil then state.selected_nm[zone_index] = 1; end
    local selected = state.selected_nm[zone_index];
    if selected > #list then selected = 1; state.selected_nm[zone_index] = 1; end

    imgui.TextColored(colors.header, zone.name);
    if zone.expansion then
        imgui.SameLine();
        imgui.TextColored(colors.muted, '(' .. zone.expansion .. ' of Abyssea)');
    end
    imgui.SameLine(740);
    imgui.TextColored(colors.muted, ('%d NMs'):format(#list));
    imgui.Separator();

    imgui.BeginChild('##nm_list_' .. zone_index, { 255, -1 }, true);
    imgui.TextColored(colors.title, 'NOTORIOUS MONSTERS');
    imgui.Separator();
    for i, entry in ipairs(list) do
        local nm = entry.nm;
        local ready = nm_ready(nm);
        local label = nm.name .. '##nm_' .. zone_index .. '_' .. i;
        if ready and nm.requirements and #nm.requirements > 0 then
            imgui.PushStyleColor(ImGuiCol_Text, colors.owned);
        end
        if imgui.Selectable(label, selected == i) then
            state.selected_nm[zone_index] = i;
            selected = i;
        end
        if ready and nm.requirements and #nm.requirements > 0 then imgui.PopStyleColor(); end
    end
    imgui.EndChild();

    imgui.SameLine();
    imgui.BeginChild('##nm_detail_' .. zone_index, { -1, -1 }, true);
    if #list > 0 then render_nm_detail(list[selected].nm, zone_index); end
    imgui.EndChild();
end

local function render_nm_pops()
    if imgui.BeginTabBar('##abyssea_zone_tabs', ImGuiTabBarFlags_FittingPolicyScroll) then
        for i, zone in ipairs(data.zones) do
            if imgui.BeginTabItem((zone.short_name or zone.name) .. '##zone_' .. i) then
                state.selected_zone = i;
                render_zone(zone, i);
                imgui.EndTabItem();
            end
        end
        imgui.EndTabBar();
    end
end

local function sorted_collection(list)
    local out = {};
    for _, entry in ipairs(list or {}) do out[#out + 1] = entry; end
    table.sort(out, function(a, b) return a.name:lower() < b.name:lower(); end);
    return out;
end

local function render_collection(list, empty_text, title)
    if #list == 0 then imgui.TextColored(colors.muted, empty_text); return; end

    local search = (title == 'ATMAS') and state.atma_search or state.abyssite_search;
    local search_label = (title == 'ATMAS') and 'Search Atmas...' or 'Search Abyssites...';

    imgui.SetNextItemWidth(360);
    imgui.InputText('##collection_search_' .. (title or 'list'), search, 128);
    if search[1] == '' and imgui.IsItemHovered() then
        imgui.SetTooltip(search_label);
    end
    imgui.SameLine();
    if imgui.SmallButton('CLEAR##collection_search_clear_' .. (title or 'list')) then search[1] = ''; end

    local all_rows = sorted_collection(list);
    local rows = {};
    local needle = normalize(search[1]);
    for _, entry in ipairs(all_rows) do
        local hay = normalize((entry.name or '') .. ' ' .. (entry.source or '') .. ' ' .. (entry.category or ''));
        if needle == '' or hay:find(needle, 1, true) then table.insert(rows, entry); end
    end

    local owned_count = 0;
    local total_owned = 0;
    for _, entry in ipairs(all_rows) do if has_keyitem(entry.name) then total_owned = total_owned + 1; end end
    for _, entry in ipairs(rows) do if has_keyitem(entry.name) then owned_count = owned_count + 1; end end

    imgui.TextColored(colors.header, title or 'COLLECTION');
    imgui.SameLine(740);
    if needle == '' then
        imgui.TextColored(colors.muted, ('%d / %d owned'):format(total_owned, #all_rows));
    else
        imgui.TextColored(colors.muted, ('%d results  |  %d / %d total owned'):format(#rows, total_owned, #all_rows));
    end
    imgui.Separator();
    imgui.TextColored(colors.muted, 'STATUS');
    imgui.SameLine(95); imgui.TextColored(colors.muted, 'NAME');
    imgui.SameLine(555); imgui.TextColored(colors.muted, 'WHERE IT COMES FROM');
    imgui.Separator();

    imgui.BeginChild('##collection_' .. (title or 'list'), { -1, -1 }, false);
    for i, entry in ipairs(rows) do
        local owned = has_keyitem(entry.name);
        local display = entry.name;
        if normalize(entry.name) == normalize('Lunar abyssite') then
            local count, total = keyitem_count(entry.name);
            if total > 1 then display = ('%s  (%d/%d)'):format(entry.name, count, total); owned = count > 0; end
        end
        imgui.TextColored(owned and colors.owned or colors.missing, owned and 'OWNED' or 'MISSING');
        imgui.SameLine(95);
        imgui.TextColored(owned and colors.owned or colors.missing, display);
        if entry.category then
            imgui.SameLine(445);
            imgui.TextColored(colors.muted, '[' .. entry.category .. ']');
        end
        if entry.source then
            imgui.SameLine(555);
            imgui.TextColored(colors.source, entry.source);
        end
        if i < #rows then imgui.Separator(); end
    end
    if #rows == 0 then imgui.TextColored(colors.muted, 'No matches.'); end
    imgui.EndChild();
end

local function render_compact()
    local zone = data.zones[state.selected_zone] or data.zones[1];
    local list = sorted_nms(zone);
    if state.selected_nm[state.selected_zone] == nil then state.selected_nm[state.selected_zone] = 1; end
    local selected = state.selected_nm[state.selected_zone];
    if selected > #list then selected = 1; state.selected_nm[state.selected_zone] = 1; end

    imgui.TextColored(colors.title, 'ABYSSEA');
    imgui.SameLine();
    imgui.TextColored(colors.muted, zone.short_name or zone.name);
    imgui.SameLine(315);
    if imgui.SmallButton('FULL##compact_full') then state.compact_mode[1] = false; end
    imgui.Separator();

    -- Small zone selector. Cycling keeps the compact window narrow.
    if imgui.SmallButton('<##compact_prev_zone') then
        state.selected_zone = state.selected_zone - 1;
        if state.selected_zone < 1 then state.selected_zone = #data.zones; end
    end
    imgui.SameLine();
    imgui.TextColored(colors.header, zone.short_name or zone.name);
    imgui.SameLine();
    if imgui.SmallButton('>##compact_next_zone') then
        state.selected_zone = state.selected_zone + 1;
        if state.selected_zone > #data.zones then state.selected_zone = 1; end
    end
    imgui.Separator();

    imgui.BeginChild('##compact_nm_list', { 150, -1 }, true);
    for i, entry in ipairs(list) do
        local nm = entry.nm;
        local ready = nm_ready(nm);
        if ready and nm.requirements and #nm.requirements > 0 then imgui.PushStyleColor(ImGuiCol_Text, colors.owned); end
        if imgui.Selectable(nm.name .. '##compact_nm_' .. i, selected == i) then
            state.selected_nm[state.selected_zone] = i;
            selected = i;
        end
        if ready and nm.requirements and #nm.requirements > 0 then imgui.PopStyleColor(); end
    end
    imgui.EndChild();

    imgui.SameLine();
    imgui.BeginChild('##compact_detail', { -1, -1 }, true);
    if #list > 0 then
        local nm = list[selected].nm;
        imgui.TextColored(nm_ready(nm) and colors.owned or colors.title, nm.name);
        imgui.SameLine(300);
        if is_nm_tracked(state.selected_zone, nm.name) then
            if imgui.SmallButton('UNTRACK##compact_track') then remove_tracked_nm(state.selected_zone, nm.name); end
        else
            if imgui.SmallButton('TRACK##compact_track') then add_tracked_nm(state.selected_zone, nm); end
        end
        imgui.Separator();
        if not nm.requirements or #nm.requirements == 0 then
            imgui.TextColored(colors.muted, nm.spawn_type or 'No tracked requirement.');
        else
            for _, req in ipairs(nm.requirements) do
                local owned, _, info = req_owned(req);
                local c = owned and colors.owned or colors.missing;
                imgui.TextColored(c, owned and 'OWNED' or 'MISSING');
                imgui.SameLine(72);
                imgui.TextColored(c, req.name or 'Unknown');
                if req.source and req.source ~= '' then
                    imgui.TextColored(colors.source, '  From: ' .. req.source);
                end
                if req.type == 'item' and owned and info ~= nil then
                    imgui.TextColored(colors.muted, ('  x%d  %s'):format(info.count or 1, table.concat(info.locations or {}, ', ')));
                end
            end
        end
    end
    imgui.EndChild();
end

ashita.events.register('load', 'abyssea_load', function()
    rebuild_lookups();
    refresh_current_ownership();
    initialize_monitor();
end);

-- Event-driven ownership updates. These handlers only react to packets that
-- FFXI is already sending to the client; the addon never polls or requests
-- inventory / key-item data from the server.
ashita.events.register('packet_in', 'abyssea_packet_in', function(e)
    -- Zone In: suppress acquisition alerts while FFXI rebuilds client state.
    if e.id == 0x000A then
        state.zoning = true;
        state.monitor_ready = false;
        state.item_event_generation = state.item_event_generation + 1;
        state.keyitem_event_generation = state.keyitem_event_generation + 1;
        state.packet_keyitems = {};
        state.packet_keyitem_pages = {};
        ashita.tasks.once(1.50, function()
            rebuild_lookups();
            refresh_current_ownership();
            initialize_monitor();
            state.zoning = false;
        end);
        return;
    end

    -- 0x01E Modify Inventory, 0x01F Item Assign, 0x020 Item Update.
    if e.id == 0x001E or e.id == 0x001F or e.id == 0x0020 then
        queue_item_event_refresh();
        return;
    end

    -- 0x055 Key Item Log. Parse the server's bitfield immediately so UI
    -- ownership does not depend on delayed client-memory synchronization.
    if e.id == 0x0055 then
        parse_keyitem_log_packet(e.data);
        queue_keyitem_event_refresh();
        return;
    end
end);

ashita.events.register('command', 'abyssea_command', function(e)
    local args = e.command:args();
    if #args == 0 then return; end
    local cmd = args[1]:lower();
    if cmd ~= '/abyssea' and cmd ~= '/aby' then return; end
    e.blocked = true;

    if #args == 1 or args[2]:lower() == 'toggle' then
        state.open[1] = not state.open[1];
    elseif args[2]:lower() == 'show' then
        state.open[1] = true;
    elseif args[2]:lower() == 'hide' then
        state.open[1] = false;
    elseif args[2]:lower() == 'refresh' then
        rebuild_lookups(); refresh_current_ownership(); initialize_monitor();
        print('[Abyssea] Ownership refreshed from local client state and saved packet data.');
    elseif args[2]:lower() == 'mode' then
        if #args >= 3 and args[3]:lower() == 'compact' then
            state.compact_mode[1] = true;
            print('[Abyssea] Compact mode enabled.');
        elseif #args >= 3 and args[3]:lower() == 'full' then
            state.compact_mode[1] = false;
            print('[Abyssea] Full mode enabled.');
        else
            state.compact_mode[1] = not state.compact_mode[1];
            print(('[Abyssea] %s mode enabled.'):format(state.compact_mode[1] and 'Compact' or 'Full'));
        end
    elseif args[2]:lower() == 'track' then
        if #args < 3 then
            print('[Abyssea] Usage: /aby track <NM name>');
        else
            local wanted = table.concat(args, ' ', 3);
            local found = nil;
            local found_zone = nil;
            for zi, zone in ipairs(data.zones) do
                for _, nm in ipairs(zone.nms or {}) do
                    if normalize(nm.name) == normalize(wanted) then found = nm; found_zone = zi; break; end
                end
                if found ~= nil then break; end
            end
            if found ~= nil then
                add_tracked_nm(found_zone, found);
                print(('[Abyssea] Tracking NM: %s'):format(found.name));
            else
                print(('[Abyssea] NM not found: %s'):format(wanted));
            end
        end
    elseif args[2]:lower() == 'untrack' then
        if #args < 3 then
            print('[Abyssea] Usage: /aby untrack <NM name>');
        else
            local wanted = table.concat(args, ' ', 3);
            local removed = false;
            for key, entry in pairs(state.tracked_nms) do
                if normalize(entry.name) == normalize(wanted) then state.tracked_nms[key] = nil; removed = true; end
            end
            print(removed and ('[Abyssea] Stopped tracking: ' .. wanted) or ('[Abyssea] NM was not pinned: ' .. wanted));
        end
    elseif args[2]:lower() == 'tracker' then
        if #args >= 3 and args[3]:lower() == 'clear' then
            state.tracked_nms = {};
            print('[Abyssea] Pinned NM tracker cleared.');
        elseif #args >= 3 and args[3]:lower() == 'on' then
            state.tracker_open[1] = true;
            print('[Abyssea] Pinned NM tracker shown.');
        elseif #args >= 3 and args[3]:lower() == 'off' then
            state.tracker_open[1] = false;
            print('[Abyssea] Pinned NM tracker hidden.');
        else
            state.tracker_open[1] = not state.tracker_open[1];
        end
    elseif args[2]:lower() == 'kicheck' then
        if #args < 3 then
            print('[Abyssea] Usage: /aby kicheck <key item id or name>');
        else
            local raw = table.concat(args, ' ', 3);
            local numeric = tonumber(raw);
            local player = AshitaCore:GetMemoryManager():GetPlayer();
            if numeric ~= nil then
                local name = AshitaCore:GetResourceManager():GetString('keyitems.names', numeric) or '<unknown>';
                local memory_owned = player ~= nil and player:HasKeyItem(numeric) or false;
                local packet_owned, packet_known = packet_has_keyitem(numeric);
                print(('[Abyssea] KI %d: %s | memory=%s | packet=%s%s | saved=%s'):format(numeric, name, tostring(memory_owned), packet_known and tostring(packet_owned) or 'unknown', packet_known and '' or ' (page not seen)', tostring(persisted_has_keyitem(numeric))));
            else
                local ids = resolve_keyitem_ids(raw) or {};
                if #ids == 0 then
                    print(('[Abyssea] No KI resource match found for: %s'):format(raw));
                else
                    for _, id in ipairs(ids) do
                        local name = AshitaCore:GetResourceManager():GetString('keyitems.names', id) or '<unknown>';
                        local memory_owned = player ~= nil and player:HasKeyItem(id) or false;
                        local packet_owned, packet_known = packet_has_keyitem(id);
                        print(('[Abyssea] KI %d: %s | memory=%s | packet=%s'):format(id, name, tostring(memory_owned), packet_known and tostring(packet_owned) or 'unknown'));
                    end
                end
            end
        end
    elseif args[2]:lower() == 'sound' then
        if #args >= 3 and args[3]:lower() == 'on' then
            state.sounds_enabled[1] = true;
            print('[Abyssea] Acquisition sounds enabled.');
        elseif #args >= 3 and args[3]:lower() == 'off' then
            state.sounds_enabled[1] = false;
            print('[Abyssea] Acquisition sounds disabled.');
        else
            state.sounds_enabled[1] = not state.sounds_enabled[1];
            print(('[Abyssea] Acquisition sounds %s.'):format(state.sounds_enabled[1] and 'enabled' or 'disabled'));
        end
    end
end);

ashita.events.register('d3d_present', 'abyssea_present', function()
    push_theme();
    render_tracker_window();
    if not state.open[1] then pop_theme(); return; end
    if state.compact_mode[1] then
        imgui.SetNextWindowSize({ 560, 390 }, ImGuiCond_FirstUseEver);
        imgui.SetNextWindowSizeConstraints({ 440, 280 }, { 800, 760 });
    else
        imgui.SetNextWindowSize({ 1320, 760 }, ImGuiCond_FirstUseEver);
        imgui.SetNextWindowSizeConstraints({ 1040, 560 }, { 1850, 1250 });
    end

    if imgui.Begin('Abyssea Tracker##integready', state.open) then
        if state.compact_mode[1] then
            render_compact();
        else
            imgui.PushStyleColor(ImGuiCol_ChildBg, { 0.055, 0.105, 0.165, 0.98 });
            imgui.BeginChild('##aby_banner', { -1, 42 }, true);
            imgui.TextColored({ 0.55, 0.84, 1.00, 1.00 }, 'ABYSSEA TRACKER');
            imgui.SameLine();
            imgui.TextColored(colors.muted, 'by IntegReady');
            imgui.SameLine(310);
            if imgui.Button('REFRESH##aby_refresh') then
                refresh_current_ownership();
                initialize_monitor();
                print('[Abyssea] Ownership refreshed from local client state and saved packet data.');
            end
            imgui.SameLine(1030);
            imgui.TextColored(state.sounds_enabled[1] and colors.owned or colors.muted, state.sounds_enabled[1] and 'SOUND ON' or 'SOUND OFF');
            imgui.EndChild();
            imgui.PopStyleColor();
            imgui.Spacing();

            if imgui.BeginTabBar('##abyssea_tabs') then
                if imgui.BeginTabItem('NM Pops') then render_nm_pops(); imgui.EndTabItem(); end
                if imgui.BeginTabItem('Abyssites') then render_collection(data.abyssites, 'No abyssites found.', 'ABYSSITES'); imgui.EndTabItem(); end
                if imgui.BeginTabItem('Atmas') then render_collection(data.atmas, 'No atmas found.', 'ATMAS'); imgui.EndTabItem(); end
                if imgui.BeginTabItem('Settings') then render_sound_settings(); imgui.EndTabItem(); end
                imgui.EndTabBar();
            end
        end
    end
    imgui.End();
    pop_theme();
end);
