Abyssea Tracker v0.6.3
by IntegReady

Install:
  Copy the 'abyssea' folder into Ashita/addons/

Load:
  /addon load abyssea

Commands:
  /aby                 Toggle window
  /aby show            Show window
  /aby hide            Hide window
  /aby refresh         Refresh key-item/item ownership and reset alert baseline
  /aby sound on        Enable acquisition chimes
  /aby sound off       Disable acquisition chimes

Features:
  - Full nine-zone NM browser with alphabetical NM lists
  - Pop item and key item ownership tracking
  - Abyssite collection and sources
  - Atma collection and sources
  - More opaque, rounded midnight-blue UI styling
  - Acquisition chimes for physical pop items, key items, Abyssites, and Atmas
  - Settings tab with master sound toggle, per-type toggles, and test buttons

Sound behavior:
  The addon records an ownership baseline when it loads. It only chimes when an
  item/key item is newly detected after that baseline, so existing collections
  should not generate a wall of sounds when loading the addon.


v0.6.3 fix:
- Physical item scans no longer stop at the first empty container slot.
- Added runtime resource-name fallback for owned pop items.
- Fixes received items such as Transparent Insect Wing remaining incorrectly red.


v0.6.3:
- Removed redundant banner subtitle.
- Key item ownership matching now supports normal FFXI resource abbreviations using the same tolerant name resolver as physical items.
- Applies to NM key items, Abyssites, and Atmas.


Pinned NM Tracker:
  /aby track <NM name>
  /aby untrack <NM name>
  /aby tracker
  /aby tracker on
  /aby tracker off
  /aby tracker clear

Use the TRACK button on any NM detail page to pin it to the transparent farming overlay.


v0.9.5:
- Larger default Full Mode window and taller header.
- Search boxes for Abyssites and Atmas.


v0.9.5 notes:
- Removed all clickable BG-Wiki/browser link behavior.
- Returned UI labels to plain text.
- Corrected missing multi-item NM pop requirements on the stable v0.9.0 base.
- No new NM rows or experimental UI behavior added in this patch.


v0.9.5: Physical pop-item ownership now uses exact Ashita resource IDs/names only. This prevents false positives while still supporting normal FFXI abbreviated display names through LogNameSingular.
